from django.apps import AppConfig


class ChequeConfig(AppConfig):
    name = 'cheque'
