from django.shortcuts import render
from .models import Cheques ,Subliers
from .models import ChequeForm
from django.views.generic import ListView, CreateView, UpdateView


def home(request):
    form = ChequeForm()
    sub = Subliers.objects.all()
    context = {'form':form}
    return render(request,'home.html',context)