from django.db import models
from django import forms
from num2words import num2words
class Subliers(models.Model):
    Name = models.CharField(max_length=200)
    timestamp = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.Name
    class Meta:
        verbose_name= 'الموردين'
        verbose_name_plural= 'الموردين'
NickName1 = [
    ('السيد', 'السيد'),
    ('السادة', 'السادة'),
    ('السيدة', 'السيدة'),

]
NickName2 = [
    ('المحترم', 'المحترم'),
    ('المحترمين', 'المحترمين'),
    ('المحترمه', 'المحترمه'),

]
class Cheques(models.Model):
    Nick = models.CharField(max_length=200,choices=NickName1 , null=True , blank=True)
    Nick1 = models.CharField(max_length=200,choices=NickName2,null=True , blank=True)
    To = models.ForeignKey(Subliers,on_delete=models.CASCADE)
    Date = models.DateField(verbose_name='التاريخ')
    JOD = models.IntegerField(verbose_name='دينار')
    Fils = models.IntegerField(null=True , blank=True ,verbose_name='فلس')
    #Mostfeed_Awal = models.BooleanField(verbose_name='المستفيد الاول ',default=True ,null=True , blank=True )

    @property
    def Convert(self):
        # return num2words(self.JOD ,lang='ar') + ' دينار اردني  و  '+  num2words(self.Fils ,lang='ar') + '   فلس فقط لا غير '

        try:
            if self.Fils:

                return num2words(self.JOD, lang='ar') + ' دينار اردني  و  ' + num2words(self.Fils,
                                                                                        lang='ar') + '   فلس فقط لا غير '
            else:
                return num2words(self.JOD, lang='ar') + ' دينار اردني فقط لا غير  '
        except:
            pass
    text = models.CharField(max_length=500,null=True,blank=True,default=str(Convert) )
    Reasone = models.TextField(null=True , blank=True )

    def __str__(self):
        return self.To.Name


    class Meta:
        verbose_name= 'الشيكات'
        verbose_name_plural= 'الشيكات'
class ChequeForm(forms.ModelForm):
    class Meta:
        model = Cheques
        fields = ('To', 'Date')

