from django.contrib import admin
from django.http import HttpResponseRedirect

from .models import Subliers ,Cheques
from django.shortcuts import render


class ChequesAdmin(admin.ModelAdmin):
    actions = ['update_status']
    list_display = ['To','JOD','Fils']
    autocomplete_fields = ['To']

    def update_status(self, request, queryset):
        # All requests here will actually be of type POST
        # so we will need to check for our special key 'apply'
        # rather than the actual request type
        if 'apply' in request.POST:
            # The user clicked submit on the intermediate form.
            # Perform our update action:
            queryset.update(status='NEW_STATUS')

            # Redirect to our admin view after our update has
            # completed with a nice little info message saying
            # our models have been updated:
            self.message_user(request,
                              "Changed status on {} orders".format(queryset.count()))
            return HttpResponseRedirect(request.get_full_path())

        return render(request,
                      'admin/cheque.html',
                      context={'t': queryset})

    admin.site.site_header = 'Harir Palace Hotel | Cheques System '
    update_status.short_description = "Update status"

    update_status.short_description = "print"
    model = Cheques
    readonly_fields = ['Convert',]
class SubliersAdmin(admin.ModelAdmin):
    search_fields = ['Name']

    #autocomplete_fields = ['To']
admin.site.register(Subliers, SubliersAdmin)
admin.site.register(Cheques,ChequesAdmin)

admin.site.site_header = 'Harir Palace Hotel | Cheques System '