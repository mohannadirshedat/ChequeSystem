
from django.contrib import admin
from django.urls import path
from cheque.views import home

urlpatterns = [
    path('', admin.site.urls),
    #path('',home ,name='home')
]
